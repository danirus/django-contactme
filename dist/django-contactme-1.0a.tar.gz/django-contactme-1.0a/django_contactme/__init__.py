"""
django_contactme - Contact form extension for Django, with email verification
"""
